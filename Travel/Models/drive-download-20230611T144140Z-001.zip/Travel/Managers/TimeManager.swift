//
//  DateManager.swift
//  Travel
//
//  Created by 新翌王 on 2023/6/10.
//

import Foundation

class TimeManager: ObservableObject {
    @Published var time = Date()
    
}
